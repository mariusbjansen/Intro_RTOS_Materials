/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                                       WIN32 PORT & LINUX PORT
*                          (c) Copyright 2004-... Werner.Zimmermann@fht-esslingen.de
*                                           All Rights Reserved
*
*               This file should contain application specific definitions, required since V2.8x
*********************************************************************************************************
*/

#ifndef APP_CFG_H
#define APP_CFG_H
#define          OS_TASK_TMR_PRIO   0

#endif

