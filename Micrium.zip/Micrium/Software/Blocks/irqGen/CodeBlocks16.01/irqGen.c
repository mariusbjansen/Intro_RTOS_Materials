/*
*********************************************************************************************************
*                                          Generate interrupt events
*                                Used to simulate interrupts for uC/OS-II WIN32 PORT
*
*                                           All Rights Reserved
*
* File : irqGen.C
* By   : Amr Ali Abdel-Naby
*********************************************************************************************************
*/


#include <windows.h>
#include <stdio.h>

HANDLE irqHandle=NULL;

int main(int argc, char *argv[])
{
    char irqName[256];
    char in = '0';

    srand(100);
    while (1)
    {

        
        in = '0' + (rand() % 5);
        
        sprintf(irqName, "OSirq%c", in);                               //Supported "interrupt" events OSirq0 ... OSirq7

        if ((irqHandle=OpenEvent(EVENT_ALL_ACCESS, FALSE, irqName))==NULL)  //Open the interrupt event (fails, if uCOS-II is not running)
        {   
            printf("Could not open %s - exiting\n", irqName);
            return -2;
        }

        SetEvent(irqHandle);                                                //Trigger the "interrupt" event
        Sleep(2);
        CloseHandle(irqHandle);
    }
    return 0;
}
